#pragma once

void function1(int number);

void function2(const char* text, int number);
